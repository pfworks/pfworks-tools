# HAL 9000 Interface - Quick Start

## Automated Installation (Recommended)

```bash
# Extract the package
tar -xzf hal9000-interface-*.tar.gz
cd hal9000-interface-*

# Run the installer
./install.sh

# Launch HAL
hal9000
```

## Troubleshooting & Testing

If you encounter PIL/ImageTk issues:

```bash
# Extract the package
tar -xzf hal9000-interface-*.tar.gz
cd hal9000-interface-*

# Run the troubleshooting script
./test_hal.sh
```

This script will:
- Check system requirements
- Fix PIL/ImageTk issues automatically
- Launch the best available HAL version

## Manual Installation

```bash
# Extract the package
tar -xzf hal9000-interface-*.tar.gz
cd hal9000-interface-*

# Install Python dependencies
pip install -r requirements.txt

# Launch directly (PIL version)
./launch_hal.sh

# Or launch PIL-free version
python3 hal_gui_no_pil.py
```

## Shell Mode Usage

1. **Launch HAL** using any method above
2. **Click "SHELL" button** in the interface
3. **Type shell commands** in cyan input field
4. **Switch back** with "Q CLI" button

See `SHELL_MODE_GUIDE.md` for detailed shell mode instructions.

## Features

- **Q CLI Mode**: Direct Amazon Q integration for AWS assistance
- **Shell Mode**: Execute bash commands with real-time output
- **HAL Aesthetic**: Authentic HAL 9000 panel image and retro styling
- **Conversation Logging**: Save and export your interactions
- **PIL-Free Fallback**: Works even without image support

## Requirements

- Python 3.6+
- tkinter (usually included)
- Amazon Q CLI (for Q mode)
- PIL/Pillow (optional, for HAL image)

The installer and test script will check all requirements and guide you through any missing dependencies.

---

*"I'm sorry, Dave. I'm afraid I can't do that."*
*But this HAL can help you with AWS and system operations!* 🚀
